from django.contrib import admin
from .models import Products
from .models import placeorder
from .models import world
# Register your models here.

admin.site.site_header = "Green Cart"
admin.site.index_title = "Manage Green cart"

class ProductAdmin(admin.ModelAdmin):
    def change_category_to_default(self,request,queryset):
        queryset.update(category="default")

    list_display =('title','price','category','description')
    search_fields =('category',)
    list_editable = ('price',)

admin.site.register(Products,ProductAdmin)
admin.site.register(placeorder)
admin.site.register(world)
