from django.db import models

class Products(models.Model):


    def __str__(self):
        return self.title
    title = models.CharField(max_length=200)
    price = models.FloatField()
    discount_price = models.FloatField()
    category = models.CharField(max_length=200)
    description = models.TextField()
    image = models.CharField(max_length=300)

class placeorder(models.Model):

    
    item = models.CharField(max_length=1000)
    name = models.CharField(max_length=200)
    email=models.CharField(max_length=200)
    address = models.CharField(max_length=1000)
    city = models.CharField(max_length=200)
    state = models.CharField(max_length=200)
    zipcode = models.CharField(max_length=200)
    total = models.CharField(max_length=200)


class world(models.Model):

    def __str__(self):
        return self.Country

    Country = models.CharField(max_length=100,blank=False)
    New_cases = models.IntegerField()
    Total_deaths = models.IntegerField()
    Total_recovered = models.IntegerField()
    Active_cases = models.IntegerField()
    Cases_per_mill = models.IntegerField()
    Deaths_per_mill = models.IntegerField()
    image=models.CharField(max_length=500,default="https://us.123rf.com/450wm/urfandadashov/urfandadashov1808/urfandadashov180821702/108720299-world-placeholder-vector-icon-isolated-on-transparent-background-world-placeholder-logo-concept.jpg?ver=6")
    