from django import forms
from .models import world

class WorldForm(forms.ModelForm):
    class Meta:
        model = world 
        fields = ['Country','New_cases','Total_deaths','Total_recovered','Active_cases','Cases_per_mill','Deaths_per_mill']
