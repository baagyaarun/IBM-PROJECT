from django.shortcuts import render,redirect
from .models import Products,placeorder
from django.http import HttpResponse
from django.core.paginator import Paginator
from .models import world
from django.template import loader
from .forms import WorldForm

def index(request):
    product_objects = Products.objects.all()
    item_name=request.GET.get('item_name')
    if item_name != '' and item_name is not None:
        product_objects=product_objects.filter(title__icontains=item_name)

    item_cate=request.GET.get('item_cate')
    if item_cate != '' and item_cate is not None:
        product_objects=product_objects.filter(category__icontains=item_cate)

    paginator=Paginator(product_objects,12)
    page=request.GET.get('page')
    product_objects=paginator.get_page(page)


    return render(request,'shop/index.html',{'product_objects':product_objects})
# Create your views here.


def detail(request,id):
    product_object =  Products.objects.get(id=id)
    return render(request,'shop/detail.html',{'product_object':product_object})
    

    
def checkout(request):

    if request.method == "POST":
        item = request.POST.get('item','') 
        name = request.POST.get('name',"")
        email = request.POST.get('email',"")
        address = request.POST.get('address',"")
        city = request.POST.get('city',"")
        state =request.POST.get('state',"")
        zipcode = request.POST.get('zipcode',"")
        total = request.POST.get('total',"")
        order = placeorder(item=item,name=name,email=email,address=address,city=city,state=state,zipcode=zipcode,total=total)
        order.save()

    return render(request,'shop/checkout.html')



def index1(request):
    world_list= world.objects.all()
    template = loader.get_template('shop/index1.html')
    context={
      'world_list':world_list,
    }
    return render(request,'shop/index1.html',context)


    
def detail1(request,world_id):
    worlds=world.objects.get(pk=world_id)
    context={
        'worlds':worlds,
    }
    return render(request,'shop/detail1.html',context)

def create(request):
    form = WorldForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('shop:index1')

    return render(request,'shop/form.html',{'form':form})

def update(request,id):
    world1=world.objects.get(id=id)
    form =WorldForm(request.POST or None,instance=world1)
    if form.is_valid():
       form.save()
       return redirect('shop:index1')

    return render(request,'shop/form.html',{'form':form,'world1':world1})

def delete(request,id):
    world1=world.objects.get(id=id)
    if request.method == 'POST':
        world1.delete()
        return redirect('shop:index1')

    return render(request,'shop/item_delete.html',{'world1':world1})


def graph(request):
    context={

    }
    return render(request,'shop/frontpage/ecom.html',context)

def end(request):
    context={

    }
    return render(request,'shop/end.html',context)