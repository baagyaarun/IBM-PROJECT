{% load static %}
$('button').click()(function(){
prompt("thank you so much for shopping with us")    
})